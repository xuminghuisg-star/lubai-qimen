#!/usr/bin/env node
const { execSync } = require('child_process');
const path = require('path');
const fs = require('fs');

const src = path.resolve(__dirname);
const skillsDir = path.join(process.env.HOME || process.env.USERPROFILE, '.claude', 'skills');

const folders = [
  { src: path.join(src, 'lubai-qimen'), name: 'lubai-qimen' },
  { src: path.join(src, 'lubai-study'),  name: 'lubai-study' },
];

if (!fs.existsSync(skillsDir)) {
  fs.mkdirSync(skillsDir, { recursive: true });
}

function copyDir(src, dest) {
  if (!fs.existsSync(dest)) fs.mkdirSync(dest, { recursive: true });
  for (const entry of fs.readdirSync(src, { withFileTypes: true })) {
    const s = path.join(src, entry.name);
    const d = path.join(dest, entry.name);
    if (entry.isDirectory()) copyDir(s, d);
    else fs.copyFileSync(s, d);
  }
}

for (const f of folders) {
  const dest = path.join(skillsDir, f.name);
  if (fs.existsSync(dest)) {
    console.log(`  ${f.name} 已存在，跳过`);
    continue;
  }
  copyDir(f.src, dest);
  console.log(`  ${f.name} → ${dest}`);
}

console.log('安装完成，重启 Claude Code 后生效');
